// reinterpret_cast.cpp
#include <iostream>
using namespace std;

//#define active
//#define ex1
//#define ex2

#ifdef active
int main() {
    #ifdef ex1
    int x = 2;
    int* p;
    p = reinterpret_cast<int*>(x);  // int and int* are unrelated 
    cout << p << endl;
    #endif 

    #ifdef ex2
    // Error case
    int x = 2;
    double y;
    y = reinterpret_cast<double>(x);  // FAILS types are related
    #endif
}
#endif
