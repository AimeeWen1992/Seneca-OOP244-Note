// dynamic_cast.cpp
#include <iostream>

class Base {
  public:
    virtual void display() const { std::cout << "Base\n"; } 
};
class Derived : public Base {
  public:
    void display() const { std::cout << "Derived\n"; } 
};

//#define active
//#define ex1
//#define ex2

#ifdef active
int main( ) {
    #ifdef ex1
    Base* b1 = new Base;
    Base* b2 = new Derived;
    // Downcasting from base to derived
    Derived* d1 = dynamic_cast<Derived*>(b1);
    Derived* d2 = dynamic_cast<Derived*>(b2);

    if (d1 != nullptr)
        d1->display();
    else
        std::cerr << "d1 is not derived" << std::endl;

    if (d2 != nullptr)
        d2->display();
    else
        std::cerr << "d2 is not derived" << std::endl;
    delete d1;
    delete d2;
    #endif

    #ifdef ex2
    Base* b;
    Derived* d = new Derived;
    // Upcasting from derived to base
    b = dynamic_cast<Base*>(d);  // in the same hierarchy 
    if (b != nullptr)
        b->display();
    else
        std::cerr << "Mismatch" << std::endl;
    d->display();
    delete d;
    #endif
}
#endif
