// position in output stream
#include <fstream> // std::ofstream
//#define seek
int main () {

  std::ofstream outfile;
  outfile.open("test.txt");
  outfile << "This is an apple";
  //outfile.write("This is an apple",16);

#ifdef seek
  long pos = outfile.tellp();
  outfile.seekp(pos-7);
  outfile << " sam";
  //outfile.write(" sam",4);
#endif

  outfile.close(); // always close the file stream
  return 0;
}
