#ifndef SDDS_CALC_H
#define SDDS_CALC_H

#include <iostream>

#define ACTIVE

namespace sdds {

#ifdef ACTIVE
  template <typename T, int N>
  class Calculator {

    T result[N];

  public:
    Calculator() {
      for (int i = 0; i < N; i++) result[i] = 0;
    }

    std::ostream& display(std::ostream& os) const {
      for (int i = 0; i < N; i++){
        os << result[i]; if (N - i > 1) os << ",";
      }
      os << std::endl;
      return os;
    }

    void add(const T* arr1, const T* arr2) {
      for (int i = 0; i < N; i++) {
        result[i] = arr1[i] + arr2[i];
      }
    }

    Calculator& operator+=(const T* arr) {
      add(this->result, arr);
      return *this;
    }
  };
#endif

}

#endif