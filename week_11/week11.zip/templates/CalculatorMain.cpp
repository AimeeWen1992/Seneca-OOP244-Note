#include <iostream>
#include <iomanip>
#include "Calculator.h"
using namespace std;
using namespace sdds;


#ifdef ACTIVE
int main() {

  // Init two calculators
  Calculator<int, 5> ical;
  Calculator<double, 5> dcal;

  cout << "***************************" << endl;
  cout << "Initializing calculators"<< endl;
  ical.display(cout);
  dcal.display(cout) << endl;

  cout << "***************************" << endl;
  cout << "Adding values to calculators"<< endl;
  int arr1[5] = { 1, 2, 3, 4, 5 };
  ical.add(arr1, arr1);
  double arr2[5] = { 1.1, 2.2, 3.3, 4.4, 5.5 };
  dcal.add(arr2, arr2);

  cout << "Values in integer cal: ";
  ical.display(cout);
  cout << "Values in double cal: ";
  dcal.display(cout) << endl;

  cout << "***************************" << endl;
  cout << "Using += operator with calculators"<< endl;
  ical += arr1;
  dcal += arr2;
  cout << "Values in integer cal: ";
  ical.display(cout);
  cout << "Values in double cal: ";
  dcal.display(cout) << endl;

  return 0;
}
#endif
