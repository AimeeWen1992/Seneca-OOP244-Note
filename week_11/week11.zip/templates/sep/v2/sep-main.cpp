#include <iostream>
#include "sep-template.h"
using namespace std;

int main() {

  int a = 1;
  int b = 2;
  cout << "a: " << a << " b: " << b << endl;
  myswap(a, b);
  cout << "a: " << a << " b: " << b << endl;
}
