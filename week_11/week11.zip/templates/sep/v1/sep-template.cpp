#include "sep-template.h"

template <typename T>
void myswap(T& a, T& b){
  T c = a;
  a = b;
  b = c;
}
