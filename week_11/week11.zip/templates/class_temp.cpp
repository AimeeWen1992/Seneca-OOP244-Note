// class templates
// a class that depicts an array structure
#include <iostream>
#include "class_temp.h"
//#define active

#ifdef active
int main(){

  Array<int, 5> arr;
  for (int i = 0; i < 5; ++i){
    arr[i] = i*i;
    std::cout << arr[i] << std::endl;
  }

  Array<char, 3> carr;
  for (int i = 0; i < 3; ++i) {
    carr[i] = i;
    std::cout << carr[i] << std::endl;
  }
}
#endif
