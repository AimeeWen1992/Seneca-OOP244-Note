#include <new>
#include <iostream>
using namespace std;
int main() {
  char* p;
  int i = 0;
  do {
    p = new (std::nothrow) char[1000010000000]; // biggg
    i++;
  } while (p != nullptr);

  std::cout << "Out of space after " << i << " attempts!\n";
}
